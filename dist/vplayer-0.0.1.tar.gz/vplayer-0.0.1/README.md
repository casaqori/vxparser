# vplayer for Samsung Smart TV's (testing branch ...)

# Copyright 2023 @Mastaaa1987

